<section class="breadcrumbs-custom">
    <div class="breadcrumbs-custom__aside bg-image context-dark" style="background-image: url(<?php echo e(asset('/')); ?>ui-asset/images/bg-image-1-1920x238.jpg);">
        <div class="container">
            <h2 class="breadcrumbs-custom__title"><?php echo e(ucwords(str_replace('-',' ',$name))); ?></h2>
        </div>
    </div>
    <div class="breadcrumbs-custom__main bg-gray-light">
        <div class="container">
            <ul class="breadcrumbs-custom__path">
                <li><a href="<?php echo e(route('/')); ?>">Home</a></li>
                <?php if(!empty($banner_title)): ?>
                    <li>
                        <a href="<?php echo e(route('banner-list')); ?>"><?php echo e(ucwords(str_replace('-',' ',$name))); ?></a>
                    </li>
                    <li class="active"><?php echo e(ucwords($banner_title)); ?></li>
                <?php elseif(!empty($service_title)): ?>
                    <li>
                        <a href="<?php echo e(route('service-list')); ?>"><?php echo e(ucwords(str_replace('-',' ',$name))); ?></a>
                    </li>
                    <li class="active"><?php echo e(ucwords($service_title)); ?></li>
                <?php else: ?>
                    <li class="active"><?php echo e(ucwords(str_replace('-',' ',$name))); ?></li>
                <?php endif; ?>
            </ul>
        </div>
    </div>
</section>
<?php /**PATH C:\xampp\htdocs\beehivetechsolutions\resources\views/ui/common/breadcrumbs.blade.php ENDPATH**/ ?>