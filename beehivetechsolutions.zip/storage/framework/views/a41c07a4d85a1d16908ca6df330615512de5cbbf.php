


<?php $__env->startSection('title'); ?>
    <?php echo e("Beehive | $name"); ?>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('body'); ?>
    
    <?php echo $__env->make('ui.common.breadcrumbs', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
    <section class="section section-lg bg-white">
        <div class="container">
            <div class="row row-50 justify-content-md-center justify-content-lg-start">
                <div class="col-md-12 col-lg-12">
                    <div class="box-inset-1 service-details-section ">
                       <div class="text-center">
                           <img src="<?php echo e($service->media->url); ?>" style="height: 50px; width: 50px" alt="banner not found"/>
                           <h3><?php echo e($service->title); ?></h3>
                           <small>Post by: <?php echo e($service->user->email); ?></small>
                           <small>Post on: <?php echo e($service->created_at); ?></small>
                       </div>

                        <p><?php echo e($service->details); ?></p>
                    </div>
                </div>
            </div>
        </div>
    </section>
    
    <?php echo $__env->make('ui.component.choose', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
    <?php echo $__env->make('ui.component.facts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
    <?php echo $__env->make('ui.component.clients', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\beehivetechsolutions\resources\views/ui/page/service-details.blade.php ENDPATH**/ ?>