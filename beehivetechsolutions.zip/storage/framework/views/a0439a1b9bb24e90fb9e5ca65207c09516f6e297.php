<!DOCTYPE html>
<html class="wide wow-animation" lang="en">
<head>
    <meta charset="utf-8">
    <meta name="format-detection" content="telephone=no">
    <meta name="viewport" content="width=device-width, height=device-height, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title><?php echo $__env->yieldContent('title'); ?></title>
    <link rel="icon" href="<?php echo e(asset('/')); ?>ui-asset/images/favicon.png" type="image/x-icon" sizes="48x48">
    <link rel="stylesheet" type="text/css" href="//fonts.googleapis.com/css?family=Lato:400,700%7CMontserrat:300,400,700%7CLato:300,400,700">
    <link rel="stylesheet" href="<?php echo e(asset('/')); ?>ui-asset/bootstrap/css/bootstrap.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
    <link rel="stylesheet" href="<?php echo e(asset('/')); ?>ui-asset/font-awesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="<?php echo e(asset('/')); ?>ui-asset/css/fonts.css">
    <link rel="stylesheet" href="<?php echo e(asset('/')); ?>ui-asset/css/style.css">
</head>
<body>
<!-- Page Loader-->
<div id="page-loader">
    <div class="page-loader-body"><img src="<?php echo e(asset('/')); ?>ui-asset/images/logo-default-200x65.png" alt="" width="200" height="65"/>
        <div class="cssload-wrapper">
            <div class="cssload-border">
                <div class="cssload-whitespace">
                    <div class="cssload-line"></div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="page">
    
    <?php echo $__env->make('ui.common.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <main>
        <?php echo $__env->yieldContent('body'); ?>
    </main>
    
    <?php echo $__env->make('ui.common.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>

<script src="<?php echo e(asset('/')); ?>ui-asset/js/core.min.js"></script>
<script src="<?php echo e(asset('/')); ?>ui-asset/bootstrap/js/bootstrap.js"></script>
<script src="<?php echo e(asset('/')); ?>ui-asset/js/script.js"></script>
</body>
</html>

<?php /**PATH C:\xampp\htdocs\beehivetechsolutions\resources\views/master.blade.php ENDPATH**/ ?>