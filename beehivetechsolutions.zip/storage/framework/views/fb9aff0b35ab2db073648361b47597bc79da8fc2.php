


<?php $__env->startSection('title'); ?>
    <?php echo e("Beehive | $name"); ?>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('body'); ?>
    
    <?php echo $__env->make('ui.common.breadcrumbs', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
    <section class="section section-lg bg-white">
        <div class="container">
            <div class="row row-50 justify-content-md-center justify-content-lg-start">
                <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-12 col-lg-12">
                        <div class="row about-area">
                            <!-- About Image -->

                            <!-- About Content -->
                            <div class="about-content  col-md-12 col-xs-12">
                                <img src=" <?php echo e($service->media->url); ?>" style="height: 50px; width: 50px" alt="">
                                <b>  <h3 class="service-content"><?php echo e($service->title); ?></h3></b>
                                <p> <?php echo e(substr($service->details, 0,200).'...'); ?></p>
                                <a class="btn" href="<?php echo e(route('service.by.slug',['slug' => $service->slug])); ?>">Read More</a>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <div class="d-flex justify-content-center">
                    <?php echo $services->links(); ?>

                </div>
            </div>
        </div>
    </section>
    
    <?php echo $__env->make('ui.component.choose', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
    <?php echo $__env->make('ui.component.facts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
    <?php echo $__env->make('ui.component.clients', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\beehivetechsolutions\resources\views/ui/page/service-list.blade.php ENDPATH**/ ?>