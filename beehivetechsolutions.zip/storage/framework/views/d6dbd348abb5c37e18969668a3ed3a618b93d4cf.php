<section class="section section-md bg-white text-center">
    <div class="container">
        <h2>Our Services</h2>
        <div class="row row-30 justify-content-md-center">
            <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-6 col-lg-4">
                <article class="box-chloe box-chloe_primary">
                    <img src="<?php echo e($service->media->url); ?>" alt="not found">
                    <div class="box-chloe__main">
                        <h4 class="box-chloe__title"><?php echo e($service->title); ?></h4>
                        <p class="wrapping-paragraph">
                            <?php echo e(substr($service->details, 0,120)); ?>

                        </p>
                        <a
                                class="button button-sm button-default button-ujarak"
                                href="<?php echo e(route('service.by.slug',['slug' => $service->slug])); ?>"
                        >
                            View Details
                        </a>
                    </div>
                </article>
            </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</section><?php /**PATH C:\wamp64\www\beehivetechsolutions\resources\views/ui/component/service.blade.php ENDPATH**/ ?>