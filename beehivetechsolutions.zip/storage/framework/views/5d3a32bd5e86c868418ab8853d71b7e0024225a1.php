<section class="section section-sm bg-white text-center">
    <div class="container">
        <h2>Why Choose Us </h2>
        <div class="row row-30 wow fadeIn">
            <?php $__currentLoopData = $chooses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $choose): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-6 col-lg-4">
                <article class="box-alice">
                    <div class="box-alice__inner">
                        <div class="box-alice__aside">
                            <div class="box-alice__icon-outer">
                                <img src="<?php echo e($choose->media->url); ?>">
                            </div>

                        </div>
                        <div class="box-alice__main">
                            <h5 class="box-alice__title"><?php echo e($choose->title); ?></h5>
                            <p><?php echo e($choose->details); ?></p>
                        </div>
                    </div>
                </article>
            </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</section><?php /**PATH C:\xampp\htdocs\beehivetechsolutions\resources\views/ui/component/choose.blade.php ENDPATH**/ ?>