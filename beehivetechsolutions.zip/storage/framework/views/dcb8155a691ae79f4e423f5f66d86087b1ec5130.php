<section class="section section-lg bg-gray-lighter text-center">
    <div class="container">
        <h2>Meet Our Team</h2>
        <div class="row row-50">
            <div class="col-md-6 col-lg-4">
                <article class="card-creative">
                    <div class="card-creative__inner">
                        <figure class="card-creative__media"><img src="<?php echo e(asset('/')); ?>ui-asset/images/team-1-230x211.jpg" alt="" width="230" height="211"/></figure>
                        <p class="card-creative__title">Atif Akram Bhuyan</p>
                        <p class="card-creative__subtitle">Founder, Managing Director</p>
                        <div class="card-creative__divider"></div>
                        <div class="card-creative__aside">
                            <ul class="list-inline list-inline-md">
                                <li><a class="icon icon-xs icon-darker icon-style-brand fa fa-facebook" href="#"></a></li>
                                <li><a class="icon icon-xs icon-darker icon-style-brand fa fa-twitter" href="#"></a></li>
                                <li><a class="icon icon-xs icon-darker icon-style-brand fa fa-instagram" href="#"></a></li>
                            </ul>
                        </div>
                    </div>
                </article>
            </div>
        </div>
    </div>
</section><?php /**PATH C:\xampp\htdocs\beehivetechsolutions\resources\views/ui/component/team.blade.php ENDPATH**/ ?>