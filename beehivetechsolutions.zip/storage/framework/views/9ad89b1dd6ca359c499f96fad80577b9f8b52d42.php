<section class="section swiper-container swiper-slider swiper_style-1 swiper_height-1 swiper-controls-classic section-overlay" data-loop="true" data-autoplay="false" data-simulate-touch="false">

    <div class="swiper-wrapper">
        <?php $__currentLoopData = $banners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $banner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <div class="swiper-slide bg-image-dark" data-slide-bg="<?php echo e($banner->media ? $banner->media->url : ''); ?>">
            <div class="swiper-slide-caption">
                <div class="container">
                    <h1 data-caption-animate="fadeInUpSmall"><span class="d-block font-weight-light"><?php echo e($banner->title); ?></span>
                        <span class="d-block font-weight-bold"><?php echo e(substr($banner->details, 0,30).'...'); ?></span></h1>
                    <div class="col-12 offset-top-60" data-caption-animate="fadeInUpSmall">
                        <a
                            class="button button-lg button-primary button-ujarak"
                            href="<?php echo e(route('banner.by.slug',['slug' => $banner->slug])); ?>">
                            Read More
                        </a>
                    </div>
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <div class="swiper-pagination"></div>
    <div class="swiper-button-prev"></div>
    <div class="swiper-button-next"></div>

</section><?php /**PATH C:\wamp64\www\beehivetechsolutions\resources\views/ui/component/banner.blade.php ENDPATH**/ ?>