


<?php $__env->startSection('title'); ?>
    <?php echo e("Beehive | ".ucwords(str_replace('-',' ',$name))); ?>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('body'); ?>
    
    <?php echo $__env->make('ui.common.breadcrumbs', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
    <section class="section section-lg bg-white">
        <div class="container">
            <div class="row row-50 justify-content-md-center justify-content-lg-start">
                <?php $__currentLoopData = $banners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $banner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-12 col-lg-12">
                        <div class="row about-area">
                            <!-- About Image -->
                            <div class="about-image col-md-3 col-xs-12 p-0"><img src=" <?php echo e($banner->media->url); ?>" alt=""></div>
                            <!-- About Content -->
                            <div class="about-content col-md-9 col-xs-12">
                                <b>  <h3><?php echo e($banner->title); ?></h3></b>
                                <p> <?php echo e(substr($banner->details, 0,200).'...'); ?></p>
                                <a class="btn" href="<?php echo e(route('banner.by.slug',['slug' => $banner->slug])); ?>">Read More</a>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <div class="d-flex justify-content-center">
                    <?php echo $banners->links(); ?>

                </div>
            </div>
        </div>
    </section>
    
    <?php echo $__env->make('ui.component.choose', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
    <?php echo $__env->make('ui.component.facts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
    <?php echo $__env->make('ui.component.clients', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\beehivetechsolutions\resources\views/ui/page/banner-list.blade.php ENDPATH**/ ?>