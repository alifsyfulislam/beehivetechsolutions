


<?php $__env->startSection('title'); ?>
    <?php echo e("Beehive | $name"); ?>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('body'); ?>
    
    <?php echo $__env->make('ui.common.breadcrumbs', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <section class="section section-md bg-gray-light">
        <div class="container">
            <!-- Bootstrap tabs-->
            <div class="card-group card-group-custom card-group-corporate" id="accordion2" role="tablist" aria-multiselectable="true">
                <div class="row row-30">
                    <?php $__currentLoopData = $faqs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $faq): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-lg-12">
                            <!-- Bootstrap card-->
                            <div class="card card-custom card-corporate">
                                <div class="card-heading" id="accordion1Heading10" role="tab">
                                    <div class="card-title"><a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion-<?php echo e($faq->id); ?>" href="#accordion-<?php echo e($faq->id); ?>" aria-controls="accordion-<?php echo e($faq->id); ?>"><?php echo e($faq->title); ?>

                                            <div class="card-arrow"></div></a>
                                    </div>
                                </div>
                                <div class="card-collapse collapse" id="accordion-<?php echo e($faq->id); ?>" role="tabpanel" aria-labelledby="accordion1Heading10">
                                    <div class="card-body">

                                        <p><?php echo e($faq->details); ?></p>
                                    </div>
                                </div>
                            </div>
                            <!-- Bootstrap card-->
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\beehivetechsolutions\resources\views/ui/page/faqs.blade.php ENDPATH**/ ?>