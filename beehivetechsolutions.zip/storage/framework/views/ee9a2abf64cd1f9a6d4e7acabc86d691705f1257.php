


<?php $__env->startSection('title'); ?>
    <?php echo e("Beehive | $name"); ?>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('body'); ?>
    
    <?php echo $__env->make('ui.common.breadcrumbs', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <section class="section section-md bg-gray-light">
        <div class="container">
            <!-- Bootstrap tabs-->
            <div class="tabs-custom tabs-horizontal tabs-creative" id="tabs-faq">
                <!-- Nav tabs-->
                <ul class="nav nav-tabs">
                    <li class="nav-item"><a class="nav-link active" href="#tabs-faq-2" data-toggle="tab">Software</a></li>
                    <li class="nav-item"><a class="nav-link" href="#tabs-faq-3" data-toggle="tab">Services</a></li>
                </ul>
                <!-- Tab panes-->
                <div class="tab-content">
                    <div class="tab-pane fade show active" id="tabs-faq-2">
                        <div class="card-group card-group-custom card-group-corporate" id="accordion2" role="tablist" aria-multiselectable="true">
                            <div class="row row-30">
                                <div class="col-lg-6">
                                    <!-- Bootstrap card-->
                                    <div class="card card-custom card-corporate">
                                        <div class="card-heading" id="accordion1Heading10" role="tab">
                                            <div class="card-title"><a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion1" href="#accordion1Collapse10" aria-controls="accordion1Collapse10">What is a unique/non-unique purchase?
                                                    <div class="card-arrow"></div></a>
                                            </div>
                                        </div>
                                        <div class="card-collapse collapse" id="accordion1Collapse10" role="tabpanel" aria-labelledby="accordion1Heading10">
                                            <div class="card-body">
                                                <p>Vitae semper quis lectus nulla at volutpat diam ut. Sed adipiscing diam donec adipiscing tristique risus nec. Lorem ipsum dolor sit amet consectetur adipiscing elit. Habitasse platea dictumst vestibulum rhoncus est pellentesque. Ac tortor vitae.</p>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- Bootstrap card-->
                                    <div class="card card-custom card-corporate">
                                        <div class="card-heading" id="accordion1Heading11" role="tab">
                                            <div class="card-title"><a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion1" href="#accordion1Collapse11" aria-controls="accordion1Collapse11">How can I pay for my order?
                                                    <div class="card-arrow"></div></a>
                                            </div>
                                        </div>
                                        <div class="card-collapse collapse" id="accordion1Collapse11" role="tabpanel" aria-labelledby="accordion1Heading11">
                                            <div class="card-body">
                                                <p>Nisi est sit amet facilisis. Duis tristique sollicitudin nibh sit amet commodo. Sed turpis tincidunt id aliquet risus feugiat in ante. Sed turpis tincidunt id aliquet. Mollis aliquam ut porttitor leo a diam sollicitudin tempor. Magna eget est lorem ipsum dolor. Turpis massa tincidunt dui ut ornare lectus. Amet justo donec enim diam vulputate ut.</p>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- Bootstrap card-->
                                    <div class="card card-custom card-corporate">
                                        <div class="card-heading" id="accordion1Heading12" role="tab">
                                            <div class="card-title"><a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion1" href="#accordion1Collapse12" aria-controls="accordion1Collapse12">Can I return an item?
                                                    <div class="card-arrow"></div></a>
                                            </div>
                                        </div>
                                        <div class="card-collapse collapse" id="accordion1Collapse12" role="tabpanel" aria-labelledby="accordion1Heading12">
                                            <div class="card-body">
                                                <p>Nisi est sit amet facilisis. Duis tristique sollicitudin nibh sit amet commodo. Sed turpis tincidunt id aliquet risus feugiat in ante. Sed turpis tincidunt id aliquet. Mollis aliquam ut porttitor leo a diam sollicitudin tempor. Magna eget est lorem ipsum dolor. Turpis massa tincidunt dui ut ornare lectus. Amet justo donec enim diam vulputate ut. Lacus laoreet non curabitur gravida arcu ac.</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <!-- Bootstrap card-->
                                    <div class="card card-custom card-corporate">
                                        <div class="card-heading" id="accordion1Heading7" role="tab">
                                            <div class="card-title"><a role="button" data-toggle="collapse" data-parent="#accordion1" href="#accordion1Collapse7" aria-controls="accordion1Collapse7" aria-expanded="true">Do you provide any scripts?
                                                    <div class="card-arrow"></div></a>
                                            </div>
                                        </div>
                                        <div class="card-collapse collapse show" id="accordion1Collapse7" role="tabpanel" aria-labelledby="accordion1Heading7">
                                            <div class="card-body">
                                                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Metus dictum at tempor commodo ullamcorper. Blandit turpis cursus in hac habitasse platea dictumst. Sit amet dictum sit amet.</p>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- Bootstrap card-->
                                    <div class="card card-custom card-corporate">
                                        <div class="card-heading" id="accordion1Heading8" role="tab">
                                            <div class="card-title"><a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion1" href="#accordion1Collapse8" aria-controls="accordion1Collapse8">What do I receive when I order a template?
                                                    <div class="card-arrow"></div></a>
                                            </div>
                                        </div>
                                        <div class="card-collapse collapse" id="accordion1Collapse8" role="tabpanel" aria-labelledby="accordion1Heading8">
                                            <div class="card-body">
                                                <p>Sed arcu non odio euismod lacinia at. Suspendisse in est ante in nibh mauris cursus. Pretium quam vulputate dignissim suspendisse. Vulputate odio ut enim blandit volutpat maecenas volutpat blandit aliquam. Facilisis mauris sit amet massa vitae.</p>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- Bootstrap card-->
                                    <div class="card card-custom card-corporate">
                                        <div class="card-heading" id="accordion1Heading9" role="tab">
                                            <div class="card-title"><a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion1" href="#accordion1Collapse9" aria-controls="accordion1Collapse9">What am I allowed to do with the templates?
                                                    <div class="card-arrow"></div></a>
                                            </div>
                                        </div>
                                        <div class="card-collapse collapse" id="accordion1Collapse9" role="tabpanel" aria-labelledby="accordion1Heading9">
                                            <div class="card-body">
                                                <p>Vestibulum mattis ullamcorper velit sed ullamcorper. Amet commodo nulla facilisi nullam. Viverra maecenas accumsan lacus vel facilisis volutpat. Quis vel eros donec ac. Mattis nunc sed blandit libero volutpat sed cras. Turpis massa sed elementum.</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="tab-pane fade" id="tabs-faq-3">
                        <div class="card-group card-group-custom card-group-corporate" id="accordion3" role="tablist" aria-multiselectable="true">
                            <div class="row row-30">
                                <div class="col-lg-6">
                                    <!-- Bootstrap card-->
                                    <div class="card card-custom card-corporate">
                                        <div class="card-heading" id="accordion1Heading16" role="tab">
                                            <div class="card-title"><a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion1" href="#accordion1Collapse16" aria-controls="accordion1Collapse16">What is a unique/non-unique purchase?
                                                    <div class="card-arrow"></div></a>
                                            </div>
                                        </div>
                                        <div class="card-collapse collapse" id="accordion1Collapse16" role="tabpanel" aria-labelledby="accordion1Heading16">
                                            <div class="card-body">
                                                <p>Vitae semper quis lectus nulla at volutpat diam ut. Sed adipiscing diam donec adipiscing tristique risus nec. Lorem ipsum dolor sit amet consectetur adipiscing elit. Habitasse platea dictumst vestibulum rhoncus est pellentesque. Ac tortor vitae.</p>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- Bootstrap card-->
                                    <div class="card card-custom card-corporate">
                                        <div class="card-heading" id="accordion1Heading15" role="tab">
                                            <div class="card-title"><a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion1" href="#accordion1Collapse15" aria-controls="accordion1Collapse15">What am I allowed to do with the templates?
                                                    <div class="card-arrow"></div></a>
                                            </div>
                                        </div>
                                        <div class="card-collapse collapse" id="accordion1Collapse15" role="tabpanel" aria-labelledby="accordion1Heading15">
                                            <div class="card-body">
                                                <p>Vestibulum mattis ullamcorper velit sed ullamcorper. Amet commodo nulla facilisi nullam. Viverra maecenas accumsan lacus vel facilisis volutpat. Quis vel eros donec ac. Mattis nunc sed blandit libero volutpat sed cras. Turpis massa sed elementum.</p>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- Bootstrap card-->
                                    <div class="card card-custom card-corporate">
                                        <div class="card-heading" id="accordion1Heading13" role="tab">
                                            <div class="card-title"><a role="button" data-toggle="collapse" data-parent="#accordion1" href="#accordion1Collapse13" aria-controls="accordion1Collapse13" aria-expanded="true">Do you provide any scripts?
                                                    <div class="card-arrow"></div></a>
                                            </div>
                                        </div>
                                        <div class="card-collapse collapse show" id="accordion1Collapse13" role="tabpanel" aria-labelledby="accordion1Heading13">
                                            <div class="card-body">
                                                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Metus dictum at tempor commodo ullamcorper. Blandit turpis cursus in hac habitasse platea dictumst. Sit amet dictum sit amet.</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <!-- Bootstrap card-->
                                    <div class="card card-custom card-corporate">
                                        <div class="card-heading" id="accordion1Heading14" role="tab">
                                            <div class="card-title"><a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion1" href="#accordion1Collapse14" aria-controls="accordion1Collapse14">What do I receive when I order a template?
                                                    <div class="card-arrow"></div></a>
                                            </div>
                                        </div>
                                        <div class="card-collapse collapse" id="accordion1Collapse14" role="tabpanel" aria-labelledby="accordion1Heading14">
                                            <div class="card-body">
                                                <p>Sed arcu non odio euismod lacinia at. Suspendisse in est ante in nibh mauris cursus. Pretium quam vulputate dignissim suspendisse. Vulputate odio ut enim blandit volutpat maecenas volutpat blandit aliquam. Facilisis mauris sit amet massa vitae.</p>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- Bootstrap card-->
                                    <div class="card card-custom card-corporate">
                                        <div class="card-heading" id="accordion1Heading18" role="tab">
                                            <div class="card-title"><a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion1" href="#accordion1Collapse18" aria-controls="accordion1Collapse18">Can I return an item?
                                                    <div class="card-arrow"></div></a>
                                            </div>
                                        </div>
                                        <div class="card-collapse collapse" id="accordion1Collapse18" role="tabpanel" aria-labelledby="accordion1Heading18">
                                            <div class="card-body">
                                                <p>Nisi est sit amet facilisis. Duis tristique sollicitudin nibh sit amet commodo. Sed turpis tincidunt id aliquet risus feugiat in ante. Sed turpis tincidunt id aliquet. Mollis aliquam ut porttitor leo a diam sollicitudin tempor. Magna eget est lorem ipsum dolor. Turpis massa tincidunt dui ut ornare lectus. Amet justo donec enim diam vulputate ut. Lacus laoreet non curabitur gravida arcu ac.</p>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- Bootstrap card-->
                                    <div class="card card-custom card-corporate">
                                        <div class="card-heading" id="accordion1Heading17" role="tab">
                                            <div class="card-title"><a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion1" href="#accordion1Collapse17" aria-controls="accordion1Collapse17">How can I pay for my order?
                                                    <div class="card-arrow"></div></a>
                                            </div>
                                        </div>
                                        <div class="card-collapse collapse" id="accordion1Collapse17" role="tabpanel" aria-labelledby="accordion1Heading17">
                                            <div class="card-body">
                                                <p>Nisi est sit amet facilisis. Duis tristique sollicitudin nibh sit amet commodo. Sed turpis tincidunt id aliquet risus feugiat in ante. Sed turpis tincidunt id aliquet. Mollis aliquam ut porttitor leo a diam sollicitudin tempor. Magna eget est lorem ipsum dolor. Turpis massa tincidunt dui ut ornare lectus. Amet justo donec enim diam vulputate ut.</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\beehivetechsolutions\resources\views/ui/page/faqs.blade.php ENDPATH**/ ?>