


<?php $__env->startSection('title'); ?>
    <?php echo e("Beehive | ".ucwords(str_replace('-',' ',$name))); ?>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('body'); ?>
    
    <?php echo $__env->make('ui.common.breadcrumbs', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
    <section class="section section-lg bg-white">
        <div class="container">
            <div class="row row-50 justify-content-md-center justify-content-lg-start">

                <div class="col-md-12 col-lg-12">
                    <div class="image-custom-1" style="margin-bottom: 20px">
                        <img src="<?php echo e($news->media->url); ?>" style="height: 450px; width: 100%" alt="banner not found"/>
                    </div>
                    <div class="box-inset-1">
                        <h3><?php echo e($news->news_title); ?></h3>
                        <small>Post by: <?php echo e($news->user->email); ?></small>
                        <small>Post on: <?php echo e($news->created_at); ?></small>
                        <p><?php echo e($news->details); ?></p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    
    <?php echo $__env->make('ui.component.choose', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
    <?php echo $__env->make('ui.component.facts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
    <?php echo $__env->make('ui.component.clients', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\beehivetechsolutions\resources\views/ui/page/news-details.blade.php ENDPATH**/ ?>