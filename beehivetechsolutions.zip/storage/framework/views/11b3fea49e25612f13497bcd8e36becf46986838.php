<section class="section section-lg bg-gray-lighter text-center">
    <div class="container">
        <h2>Meet Our Team</h2>
        <div class="row row-50">
            <?php $__currentLoopData = $teams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $team): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-4 col-lg-4">
                    <article class="card-creative">
                        <div class="card-creative__inner">
                            <figure class="card-creative__media"><img src="<?php echo e($team->media->url); ?>" alt="" width="230" height="211"/></figure>
                            <?php if(!empty($team->middle_name)): ?>
                                <p class="card-creative__title"><?php echo e($team->first_name.' '.$team->middle_name.' '.$team->last_name); ?></p>
                            <?php else: ?>
                                <p class="card-creative__title"><?php echo e($team->first_name.' '.$team->last_name); ?></p>
                            <?php endif; ?>
                            <p class="card-creative__subtitle"><?php echo e($team->designation); ?></p>
                            <div class="card-creative__divider"></div>
                            <div class="card-creative__aside">
                                

                                <ul class="list-inline list-inline-md">
                                    <?php $__currentLoopData = $team->social_links; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($key===0): ?>
                                            <li><a class="icon icon-xs icon-darker icon-style-brand fa fa-facebook" href="<?php echo e($item); ?>"></a></li>
                                        <?php elseif($key===1): ?>
                                            <li><a class="icon icon-xs icon-darker icon-style-brand fa fa-twitter" href="<?php echo e($item); ?>"></a></li>
                                        <?php elseif($key===2): ?>
                                            <li><a class="icon icon-xs icon-darker icon-style-brand fa fa-instagram" href="<?php echo e($item); ?>"></a></li>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </ul>
                            </div>
                        </div>
                    </article>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</section><?php /**PATH C:\wamp64\www\beehivetechsolutions\resources\views/ui/component/team.blade.php ENDPATH**/ ?>