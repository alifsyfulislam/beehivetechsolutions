<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Client extends Model
{
    use HasFactory;

    protected $fillable = ['id','first_name','middle_name','last_name','slug','details','status','type','email'];

    public function media()
    {

        return $this->morphOne(Media::class, 'mediable');

    }

    public function user()
    {

        return $this->belongsTo(User::class,'user_id','id');

    }

    public function getCreatedAtAttribute($date)
    {

        return date('j M, Y', strtotime($date));

    }

    /**
     * @param $date
     * @return string
     */
    public function getUpdatedAtAttribute($date)
    {

        return date('j M, Y', strtotime($date));

    }
}
