<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Services\UserService;
use Illuminate\Http\Request;

class UserController extends Controller
{
    protected $userService;

    public function __construct(UserService $userService)
    {
        // $this->middleware('acl:super-admin');
        $this->userService = $userService;
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        return $this->userService->listItems($request);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        return $this->userService->createItem($request);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        return $this->userService->showItem($id);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        return $this->userService->updateItem($request,$id);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        return $this->userService->deleteItem($id);
    }

    public function changeItemStatus(Request $request, $id)
    {

        return $this->userService->changeItemStatus($request, $id);

    }

    public function checkUniqeInfo(Request $request){
        return $this->userService->checkUniqueIdentity($request);
    }

    public function logout(Request $request) {

        if ($request->user()->token()->revoke()){
            return response()->json([
                'status'        => config('status.status_code.200'),
                'message'       => 'Logged out successfully!'
            ]);

        } else{
            return response()->json([
                'status'        => config('status.status_code.200'),
                'message'       => "Could not logout!"
            ]);
        }
    }
}
