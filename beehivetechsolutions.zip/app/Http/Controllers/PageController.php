<?php

namespace App\Http\Controllers;

use App\Models\Banner;
use App\Models\Choose;
use App\Models\Client;
use App\Models\Faqs;
use App\Models\News;
use App\Models\Service;
use App\Models\Team;
use Illuminate\Http\Request;

class PageController extends Controller
{
    public function index(){
        $banners = Banner::with('media')->where('status','=','1')->orderBy('created_at','DESC')->take(3)->get();
        $services = Service::with('media')->where('status','=','1')->orderBy('created_at','DESC')->get();
        $chooses = Choose::with('media')->where('status','=','1')->orderBy('created_at','DESC')->get();
        $clients = Client::with('media')->where('status','=','1')->orderBy('created_at','DESC')->take(3)->get();
        $newses = News::with('media','user')->where('status','=','1')->orderBy('created_at','DESC')->get();


        return view('ui.index',[
            'name'          => '/',
            'banners'       => $banners,
            'services'      => $services,
            'chooses'       => $chooses,
            'clients'       => $clients,
            'newses'        => $newses
        ]);
    }

    public function aboutUsViewController(){
        $chooses    = Choose::with('media')->where('status','=','1')->orderBy('created_at','DESC')->get();
        $services   = Service::with('media','user')->where('status','=','1')->get();
        $newses     = News::with('media','user')->where('status','=','1')->orderBy('created_at','DESC')->get();
        $teams      = Team::with('media')->where('status','=','1')->orderBy('created_at','DESC')->get();

        foreach ($teams as $team){
            $team->social_links = explode(',',$team->social_links);
        }
        return view('ui.page.about-us',[
            'name'          => 'about-us',
            'chooses'       => $chooses,
            'services'      => $services,
            'newses'        => $newses,
            'teams'         => $teams
        ]);
    }


    public function bannerViewController($slug){
        $newses = News::with('media','user')->where('status','=','1')->paginate(3);
        $banner = Banner::with('media','user')->where('slug','=',$slug)->where('status','=','1')->first();
        $chooses = Choose::with('media')->where('status','=','1')->orderBy('created_at','DESC')->get();
        $clients = Client::with('media')->where('status','=','1')->orderBy('created_at','DESC')->take(3)->get();
        $services = Service::with('media','user')->where('status','=','1')->get();
        return view('ui.page.banner-details',[
            'name'          => 'banner-list',
            'banner'        => $banner,
            'banner_title'  => $banner->title,
            'chooses'       => $chooses,
            'clients'       => $clients,
            'services'      => $services,
            'newses'        => $newses
        ]);
    }


    public function bannerListController(){
        $newses = News::with('media','user')->where('status','=','1')->paginate(3);
        $services = Service::with('media','user')->where('status','=','1')->get();
        $banners = Banner::with('media','user')->where('status','=','1')->paginate(3);
        $chooses = Choose::with('media')->where('status','=','1')->orderBy('created_at','DESC')->get();
        $clients = Client::with('media')->where('status','=','1')->orderBy('created_at','DESC')->take(3)->get();
        return view('ui.page.banner-list',[
            'name'           => 'banner-list',
            'banners'        => $banners,
            'chooses'        => $chooses,
            'clients'        => $clients,
            'services'       => $services,
            'newses'         => $newses
        ]);
    }

    public function serviceViewController($slug){
        $newses = News::with('media','user')->where('status','=','1')->paginate(3);
        $services = Service::with('media','user')->where('status','=','1')->get();
        $service = Service::with('media','user')->where('slug','=',$slug)->where('status','=','1')->first();
        $chooses = Choose::with('media')->where('status','=','1')->orderBy('created_at','DESC')->get();
        $clients = Client::with('media')->where('status','=','1')->orderBy('created_at','DESC')->take(3)->get();
        return view('ui.page.service-details',[
            'name'           => 'service-list',
            'service'        => $service,
            'service_title'  => $service->title,
            'chooses'        => $chooses,
            'clients'        => $clients,
            'services'       => $services,
            'newses'         => $newses
        ]);
    }


    public function serviceListController(){
        $newses = News::with('media','user')->where('status','=','1')->paginate(3);
        $services = Service::with('media','user')->where('status','=','1')->paginate(3);
        $chooses = Choose::with('media')->where('status','=','1')->orderBy('created_at','DESC')->get();
        $clients = Client::with('media')->where('status','=','1')->orderBy('created_at','DESC')->take(3)->get();
        return view('ui.page.service-list',[
            'name'           => 'service-list',
            'services'       => $services,
            'chooses'        => $chooses,
            'clients'        => $clients,
            'newses'         => $newses
        ]);
    }


    public function newsListController(){
        $services = Service::with('media','user')->where('status','=','1')->get();
        $newses = News::with('media','user')->where('status','=','1')->paginate(3);
        $chooses = Choose::with('media')->where('status','=','1')->orderBy('created_at','DESC')->get();
        $clients = Client::with('media')->where('status','=','1')->orderBy('created_at','DESC')->take(3)->get();
        return view('ui.page.news-list',[
            'name'           => 'news-list',
            'services'       => $services,
            'newses'         => $newses,
            'chooses'        => $chooses,
            'clients'        => $clients
        ]);
    }


    public function newsViewController($slug){
        $newses = News::with('media','user')->where('status','=','1')->paginate(3);
        $services = Service::with('media','user')->where('status','=','1')->get();
        $news = News::with('media','user')->where('slug','=',$slug)->where('status','=','1')->first();
        $chooses = Choose::with('media')->where('status','=','1')->orderBy('created_at','DESC')->get();
        $clients = Client::with('media')->where('status','=','1')->orderBy('created_at','DESC')->take(3)->get();
        return view('ui.page.news-details',[
            'name'           => 'service-list',
            'news'           => $news,
            'news_title'     => $news->title,
            'chooses'        => $chooses,
            'clients'        => $clients,
            'services'       => $services,
            'newses'         => $newses
        ]);
    }

    public function faqsViewController(){
        $services = Service::with('media','user')->where('status','=','1')->get();
        $newses = News::with('media','user')->where('status','=','1')->paginate(3);
        $faqs = Faqs::with('user')->where('status','=','1')->get();
        return view('ui.page.faqs',[
            'name'           => 'faqs',
            'services'       => $services,
            'newses'         => $newses,
            'faqs'           => $faqs
        ]);
    }

    public function contactViewController(){
        $services = Service::with('media','user')->where('status','=','1')->get();
        $newses = News::with('media','user')->where('status','=','1')->paginate(3);
        return view('ui.page.contact-us',[
            'name' => 'contact-us',
            'services'      => $services,
            'newses'        => $newses
        ]);
    }
}
